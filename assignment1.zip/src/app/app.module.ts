//Modules
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';

//Component
import { AppComponent } from './app.component';
import { CustomerComponent } from './customer/customer.component';

//Services
import { CustomerService } from './customer/services/customer.service';
import { ShoppinghomeComponent } from './shopping/shoppinghome/shoppinghome.component';
import { TopmenuComponent } from './top/topmenu/topmenu.component';
import { ShareService } from './services/share.service';
import { ShoppingService } from './shopping/service/shopping.service';

@NgModule({
  declarations: [
    AppComponent,
    CustomerComponent,
    ShoppinghomeComponent,
    TopmenuComponent
  ],
  imports: [
    BrowserModule,HttpModule
  ],
  providers: [CustomerService,ShareService,ShoppingService],
  bootstrap: [AppComponent]
})
export class AppModule { }
