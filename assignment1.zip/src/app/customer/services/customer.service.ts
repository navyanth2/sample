import { Injectable } from '@angular/core';
import { Http , Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import { ICustomers } from '../model/customers';  


@Injectable()
export class CustomerService {

  private customersurl="assets/json/customers.json";
  constructor(private http:Http) { }
  getCustomers():Observable<ICustomers[]>{
    return this.http.get(this.customersurl)
    .map((response:Response)=><ICustomers[]> response.json());
  }
}
