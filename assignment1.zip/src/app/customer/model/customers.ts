export interface ICustomers{
    id: number;
    name: string;
    company: string;
    designation: string;
    emailAddress: string;
   }
   