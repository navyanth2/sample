import { Component, OnInit } from '@angular/core';
import { CustomerService } from './services/customer.service';
import { ICustomers } from './model/customers';
import { Observable } from 'rxjs/Observable';



@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  customers:ICustomers[];
  customer:ICustomers[]=new Array<ICustomers>();
  id:number;
  name:string;
  company:string;
  designation:string;
  mail:string;
  toggle:boolean=false;
  toggle1:boolean=false;

  constructor(private service:CustomerService) { 
   }
 
  ngOnInit() {
    this.service.getCustomers().subscribe(customers=>{for(let i of customers)
      {
        this.customer.push(i);
     }
    });
  }
showInformation(index)
{
  this.toggle1=false;
  this.id= this.customer[index].id;
  this.name= this.customer[index].name;
  this.company= this.customer[index].company;
  this.designation= this.customer[index].designation;
  this.mail= this.customer[index].emailAddress;
  this.toggle=true;
}

tableFormat(id){
  let index =id-1;
  this.id= this.customer[index].id;
  this.name= this.customer[index].name;
  this.company= this.customer[index].company;
  this.designation= this.customer[index].designation;
  this.mail= this.customer[index].emailAddress;
  this.toggle1=true;
}
}
