import { Component, OnInit } from '@angular/core';
import { ShoppingService } from '../service/shopping.service';

@Component({
  selector: 'app-shoppinghome',
  templateUrl: './shoppinghome.component.html',
  styleUrls: ['./shoppinghome.component.css']
})
export class ShoppinghomeComponent implements OnInit {
  imgArr = new Array();
  arr = new Array();
  product;
  imgfirst;
  count:number=0;
  k=0;
  constructor(private products: ShoppingService) { }

  ngOnInit() {
    this.products.getProducts().subscribe((data) => {
      this.product=data;
      for(let i of data.CO)
      {
        if((this.count++)==0)
        {
          this.imgfirst=i['product-image-url'];
        }
        else{
      this.imgArr.push(i);
        }
        this.arr.push(i);
      }
     
    });
  }

  changeType(id)
  {
    this.count=0;
    this.arr=new Array();
    for(let img of this.imgArr)
    {
      this.imgArr.pop();
    }
   
    console.log(this.imgArr)
    console.log(this.arr)
    if(id==1)
    {
      for(let i of this.product.CO)
      {
        if((this.count++)==0)
        {
          this.imgfirst=i['product-image-url'];
        }
        else{
      this.imgArr.push(i);
        }
        this.arr.push(i);
      }
    }
    else{
      for(let i of this.product.WI)
      {
        if((this.count++)==0)
        {
          this.imgfirst=i['product-image-url'];
        }
        else{
      this.imgArr.push(i);
        }
        this.arr.push(i);
      }
    }
     
    }
}
