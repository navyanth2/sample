import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShoppinghomeComponent } from './shoppinghome.component';

describe('ShoppinghomeComponent', () => {
  let component: ShoppinghomeComponent;
  let fixture: ComponentFixture<ShoppinghomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShoppinghomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShoppinghomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
