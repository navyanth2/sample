import { Injectable } from '@angular/core';
import { Http , Response } from '@angular/http';
import 'rxjs/add/operator/map';



@Injectable()
export class ShoppingService {

  private ProductURl="assets/json/products.json";
  constructor(private http:Http) { }
  getProducts(){
    return this.http.get(this.ProductURl)
    .map((response:Response)=>response.json());
  }

}
