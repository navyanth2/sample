import { Component,OnInit } from '@angular/core';
import { ShareService } from './services/share.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'app';
  toggle:boolean;
  constructor(private share:ShareService){

  }

  ngOnInit() {
    this.share.toggleCondition.subscribe(toggle=>this.toggle=toggle);
  }

}
