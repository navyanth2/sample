import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
@Injectable()
export class ShareService {

  constructor() { }
  private toggleComponent = new BehaviorSubject<boolean>(true);
  toggleCondition = this.toggleComponent.asObservable();
  toggle(condition: boolean) {
    this.toggleComponent.next(condition)
  }
}
