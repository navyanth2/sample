import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { ProductComponent } from './product.component';
import { InventoryComponent } from './inventory.component';
import { PageNotFoundComponent } from './NotFound.component';
export const appRoutes: Routes = [
 { path: 'Product', component: ProductComponent },
 { path: 'Inventory', component: InventoryComponent },
  { path: '',   redirectTo: '/Login', pathMatch: 'full' },
  { path: 'Login', component: LoginComponent },
  { path: 'Welcome', component: WelcomeComponent },
 
   { path: '**', component: PageNotFoundComponent },

];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: true } // <-- debugging purposes only
    )
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {}