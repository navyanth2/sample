import { Component } from '@angular/core';

@Component({
  selector: 'app-demo',

  template: 'Not found'
})
export class PageNotFoundComponent {
}
