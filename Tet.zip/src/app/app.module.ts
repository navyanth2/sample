import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ProductComponent } from './product.component';
import { InventoryComponent } from './inventory.component';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.router.module';
import { LoginComponent } from './login/login.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { HttpModule } from '@angular/http';
import { PageNotFoundComponent } from './NotFound.component';


// const appRoutes: Routes = [
// { path: 'Product', component: ProductComponent },
// { path: 'Inventory', component: InventoryComponent },
// //{ path: 'Login', component: LoginComponent },

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    WelcomeComponent,
    InventoryComponent,
    ProductComponent,
   PageNotFoundComponent
  ],
  imports: [
    BrowserModule, HttpModule, AppRoutingModule // , RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
