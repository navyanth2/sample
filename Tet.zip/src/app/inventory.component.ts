import { Component } from '@angular/core';



@Component({
  selector: 'app-demo',
  template: 'Inventory'
})
export class InventoryComponent {
}
