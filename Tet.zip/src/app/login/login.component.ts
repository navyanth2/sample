import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

 user: any;
 pwd: any;
   constructor(private _router: Router) {}

  login() {

    if(this.user== 'a' && this.pwd== 'b')
    {
      alert("succ");
  this._router.navigate(['/Welcome']);
    }else
      alert('invalid details ');

} }
