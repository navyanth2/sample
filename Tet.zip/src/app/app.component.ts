import { Component, OnInit } from '@angular/core';
import { IProduct } from './product';
import { ProductService } from './product.service';
// import { appService } from './app.service';
import { Http , Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-root',
   templateUrl: './app.component.html',
 /* template: `<ul>
<li><a [routerLink]="['/Product']">Product</a></li>
<li><a [routerLink]="['/Inventory']">Inventory</a></li>
<li><a [routerLink]="['/Login']">Login</a></li>
 <li><a href='df'>test</a></li>
</ul>
<router-outlet></router-outlet>`,*/
  providers: [ProductService]
})
export class AppComponent {

  iproducts: IProduct[];
  constructor(private _product: ProductService) {}
  ngOnInit() {
    this._product.getProducts()
    .subscribe(iproducts => this.iproducts= iproducts);
  }

}
